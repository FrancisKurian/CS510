# CS510_Project_Fall_2021
Before running the .rmd file, MAKE SURE YOU RUN RSTUDIO AS ADMINISTRATOR! Failing to run as admin will cause Rstudio to crash when opening the password-protected Excel file.

Make sure you have Microsoft Excel installed since there are password-protected .xlsx files.
Install "excel.link" and "tidyverse" next.

Note that "Hoang_Project-Create-Report.Rmd" will set the working directory to where the file is located

COMPLETE. The purpose of this script is to extract specific data from the three folders (Machine A/ Machine B/ Machine C) in the "Working" directory and combine them into a presentable report. 

INCOMPLETE. The report will indicate which specimens were analyzed and create a pass/fail criteria for the value "xBa", which is a variable found in all three datasets.

INCOMPLETE. When reviewing the report, the user will determine if the specimens are error-free or not. If there are no errors, the data will be transferred to the their respective folders in "Final" directory. This transfer is logged in a monthly log stored in "Logs".
